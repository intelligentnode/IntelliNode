import { SageMakerRuntimeClient, InvokeEndpointCommand } from "@aws-sdk/client-sagemaker-runtime";
import { ConnHelper } from "intellinode";

const internal_endpoint = process.env.llama_endpoint;
const client = new SageMakerRuntimeClient();

export const handler = async (event) => {
    console.log("--> Event: ", JSON.stringify(event));
    
    return ConnHelper.lambdaSagemakerInputPass(internal_endpoint,
                                    event,
                                    client,
                                    InvokeEndpointCommand); 
};